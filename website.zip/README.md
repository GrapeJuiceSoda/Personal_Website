# Personal_Website
Inspired by Cat-V, imageboards, and amce text editor

![](rmpic/front_page.png)
![](rmpic/blog_page.png)



